<?php
/*
 * Add here your functions below, and overwrite native theme functions
 */
 
add_action( 'wp_enqueue_scripts', 'ewa_pikme_theme_enqueue_parent_styles' );
function ewa_pikme_theme_enqueue_parent_styles() {
wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
} 
 

